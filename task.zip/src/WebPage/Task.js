import React from "react";

const Task = () => {
  return (
    <div>
      <div class="heading">
        <h1>Explore</h1>
        <p>From one guest room to</p>
        <p>penthouses with pool and gardens</p>
      </div>
      <div class="images">
        <div class="left">
          <div>
            <img src="https://img.freepik.com/free-photo/3d-rendering-modern-dining-room-living-room-with-luxury-decor_105762-2000.jpg?size=626&ext=jpg&ga=GA1.2.1168831157.1644922700" />
            <div class="postion" style={{ display: "flex" }}>
            <div class="first_content">
              <p>room with one king size bed</p>
              <div class="price"
                style={{
                  display: "flex",
                  marginTop: "-15px",
                  marginLeft: "25px",
                }}
              >
                <p id="tag_line">35$</p>
                <p id="tag_line">345K</p>
                <button type="button" id="button">
                Book
              </button>
              </div>
            </div>
            {/* <div class="second"> */}
              {/* <button type="button" id="button">
                Book
              </button> */}
            {/* </div> */}
          </div>
          </div>
          
        </div>
        <div class="right">
          <div>
            <img src="https://img.freepik.com/free-photo/cozy-sitting-room-design-with-dark-furniture-walls-combined-decoration_295714-924.jpg?w=996" />
            <div class="postion1" style={{ display: "flex" }}>
            <div class="first_content">
              <p>Penthouse for 8 Persons</p>
              <div
                style={{
                  display: "flex",
                  marginTop: "-15px",
                  marginLeft: "25px",
                }}
              >
                <p id="tag_line">2039$</p>
                <p id="tag_line">350$</p>
                <button type="button" id="button">
                Book
              </button>
              </div>
            </div>
          </div>
          </div>
          
        </div>
      </div>
      <div class="heading" style={{ marginTop: "50px" }}>
        <h3>About Us</h3>
        <p>Allows us to tell a shortstory</p>
      </div>
      <div class="images">
        <div class="left">
          <div>
            <img src="https://img.freepik.com/free-photo/3d-rendering-modern-luxury-bedroom-suite-night-with-cozy-design_105762-577.jpg?w=740" />
          </div>
          <div class="postion">
            <div class="first_content">
              <h5>chapter</h5>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            </div>
          </div>
          <div style={{ marginTop: "20px" }}>
            <img src="https://img.freepik.com/free-photo/3d-render-modern-home-office_1048-10248.jpg?t=st=1647579891~exp=1647580491~hmac=356d2f9e63fe98588b8e10c3ba9968f4adfe5b424bc19a8c1de008f2665923e8&w=740" />
          </div>
          <div class="postion">
            <div class="first_content">
              <h5>chapter</h5>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            </div>
          </div>
        </div>
        <div class="right">
          <div>
            <img src="https://images.pexels.com/photos/3356416/pexels-photo-3356416.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" />
          </div>
          <div class="postion1">
            <div class="first_content">
              <h5>chapter</h5>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            </div>
          </div>
          <div style={{ marginTop: "20px" }}>
            <img src="https://images.pexels.com/photos/1457842/pexels-photo-1457842.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" />
          </div>
          <div class="postion1">
            <div class="first_content">
              <h5>chapter</h5>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Task;
