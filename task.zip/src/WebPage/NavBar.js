import React from "react";

const NavBar = () => {
  return (
    <>
      <header class="home">
        <div class="brand-logo">
          <a href="#">
            <p>Your Logo</p>
          </a>
        </div>
        <input type="checkbox" id="toggle-btn" />
        <label for="toggle-btn" class="show-menu-btn">
          <i class="fas fa-bars"></i>
        </label>
        <nav>
          <ul class="navigation">
            <li>
              <a href="#"> Explore</a>
            </li>
            <li>
              <a href="#"> About us</a>
            </li>
            <li>
              <a href="#"> cities</a>
            </li>
            
            {/* <li><a href="#"> Support</a></li> */}
            {/* <li><a href="#"> Contact Us</a></li> */}
            <label for="toggle-btn" class="hide-menu-btn">
              <i class="fas fa-times"></i>
            </label>
          </ul>
        </nav>

        <div class="home_content">
          <div class="title">
            <h1>RethinK your Living & renting</h1>
            <h2>make your stay painless with us</h2>
          </div>
          <div class="div_container">
            <div class="first_div">
              <h4>select your city</h4>
            </div>
            <div class="second_div">
              <h4>select your dates</h4>
            </div>
            <div class="third_div">
              <h4>Add guest</h4>
            </div>
            <div class="fourth_div">
              <h4>search</h4>
            </div>
          </div>
        </div>
      </header>
    </>
  );
};

export default NavBar;
