import React from "react";

const HomeNavbar = () => {
  return (
    <div>
      <nav className="navbar text-white bg-dark navbar-dark navbar-expand-md">
        <div className="container">
          <div className="navbar-bard">
            <p className="h5">Contact</p>
          </div>
        </div>
      </nav>
    </div>
  );
};

export default HomeNavbar;
